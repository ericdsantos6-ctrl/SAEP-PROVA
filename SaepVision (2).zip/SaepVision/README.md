# SAEPVision 📸

## Sobre o projeto

O SAEPVision é uma plataforma de compartilhamento de fotografias, desenvolvida para permitir que fotógrafos publiquem suas imagens e que usuários possam visualizar e interagir com as publicações.

## Funcionalidades

- Login de usuários e fotógrafos.
- Visualização de fotografias.
- Pesquisa de fotógrafos.
- Cadastro de fotografias.
- Upload de imagens.
- Curtidas nas publicações.
- Visualização de perfil.
- Contagem de curtidas e publicações.
- Gerenciamento das próprias publicações.
- Logout.

## Tecnologias utilizadas

- HTML5
- CSS3
- JavaScript
- Node.js
- Express
- MySQL
- Multer
- Express Session
- Dotenv

## Estrutura do projeto

```text
SAEPVision/
│
├── public/
│   ├── assets/
│   │   ├── arquivo_csv/
│   │   ├── fonte/
│   │   ├── icones/
│   │   └── imagens_usuarios/
│   │
│   ├── uploads/
│   ├── index.html
│   ├── style.css
│   └── app.js
│
├── database.sql
├── server.js
├── package.json
├── package-lock.json
├── .env
├── .env.example
└── README.md