
const $ = seletor => document.querySelector(seletor);

let me = null;
let all = [];

async function api(url, options = {}) {
    const resposta = await fetch('/api' + url, {
        credentials: 'same-origin',
        ...options
    });

    const dados = await resposta.json();

    if (!resposta.ok) {
        throw new Error(dados.erro || 'Erro na operação.');
    }

    return dados;
}

function msg(texto = '') {
    $('#notice').textContent = texto;
}

function esc(valor = '') {
    return String(valor).replace(/[&<>"']/g, caractere => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    })[caractere]);
}

function imagePath(imagem) {
    if (!imagem) {
        return '/assets/imagens_usuarios/usuario-padrao.jpg';
    }

    if (/^https?:\/\//i.test(imagem)) {
        return imagem;
    }

    if (imagem.startsWith('/')) {
        return imagem;
    }

    if (imagem.startsWith('assets/')) {
        return '/' + imagem;
    }

    return '/uploads/' + encodeURIComponent(imagem);
}

function render(lista) {
    $('#gallery').innerHTML = lista.map(p => `
        <article class="photo">
            <img
                src="${esc(imagePath(p.imagem))}"
                alt="${esc(p.titulo)}"
                loading="lazy"
            >

            <div class="hover">
                <b>Foto tirada por: ${esc(p.nome || p.nome_usuario)}</b>
                <span>Local: ${esc(p.local_foto)}</span>
            </div>

            <div class="info">
                <b>${esc(p.titulo)}</b>

                <button
                    class="like"
                    type="button"
                    data-like="${Number(p.id_publicacao)}"
                >
                    <img
                        src="/assets/icones/coracao.svg"
                        alt="Curtir"
                        style="filter:${p.curtida_usuario
                            ? 'invert(14%) sepia(99%) saturate(7000%) hue-rotate(0deg)'
                            : 'none'}"
                    >
                    ${Number(p.curtidas) || 0}
                </button>
            </div>
        </article>
    `).join('') || '<p>Nenhuma fotografia encontrada.</p>';

    document.querySelectorAll('[data-like]').forEach(botao => {
        botao.onclick = () => like(botao.dataset.like);
    });
}

async function load() {
    all = await api('/publicacoes');
    render(all);
}

function openLogin() {
    $('#modal').hidden = false;
    $('#loginError').textContent = '';
}

function closeLogin() {
    $('#modal').hidden = true;
}

async function updateUser() {
    if (!me) {
        $('#userName').textContent = 'SAEPVision';
        $('#avatar').src = '/assets/imagens_usuarios/saepVision.jpeg';
        $('#profile').disabled = true;
        $('#admin').hidden = true;
        $('#loginOpen').textContent = 'Login';
        return;
    }

    $('#userName').textContent = me.nome;

    $('#avatar').src = me.imagem_usuario
        ? imagePath(me.imagem_usuario)
        : '/assets/imagens_usuarios/usuario-padrao.jpg';

    $('#profile').disabled = me.tipo !== 'fotografo';
    $('#admin').hidden = me.tipo !== 'fotografo';
    $('#loginOpen').textContent = 'Sair';
}

$('#loginOpen').onclick = async () => {
    if (!me) {
        openLogin();
        return;
    }

    try {
        await api('/logout', { method: 'POST' });

        me = null;

        await updateUser();
        await load();

        msg('Você saiu da sua conta.');

    } catch (erro) {
        msg(erro.message);
    }
};

$('#close').onclick = closeLogin;
$('#cancel').onclick = closeLogin;

$('#modal').onclick = evento => {
    if (evento.target === $('#modal')) {
        closeLogin();
    }
};

$('#profile').onclick = () => {
    if (me?.tipo === 'fotografo') {
        openSide();
    }
};

$('#loginForm').onsubmit = async evento => {
    evento.preventDefault();

    try {
        const dados = Object.fromEntries(
            new FormData(evento.target)
        );

        const resposta = await api('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        });

        me = resposta.usuario;

        closeLogin();
        evento.target.reset();

        await updateUser();
        await load();

        msg('Login realizado com sucesso!');

    } catch (erro) {
        $('#loginError').textContent = erro.message;
    }
};

async function like(id) {
    if (!me) {
        openLogin();
        return;
    }

    try {
        await api('/curtidas/' + id, {
            method: 'POST'
        });

        await load();

    } catch (erro) {
        msg(erro.message);
    }
}

async function openSide() {
    try {
        const dados = await api('/perfil');

        $('#sideName').textContent = me.nome;

        $('#stats').textContent =
            `${dados.likes} Likes • ${dados.publicacoes} Publicações`;

        $('#side').hidden = false;

    } catch (erro) {
        msg(erro.message);
    }
}

$('#sideClose').onclick = () => {
    $('#side').hidden = true;
};

$('#myPosts').onclick = async () => {
    if (!me) return;

    try {
        const minhas = all.filter(
            p => Number(p.id_usuario) === Number(me.id_usuario)
        );

        render(minhas);

        $('#side').hidden = true;

        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });

        msg('Estas são suas publicações.');

    } catch (erro) {
        msg(erro.message);
    }
};

$('#logout').onclick = async () => {
    try {
        await api('/logout', {
            method: 'POST'
        });

        me = null;

        $('#side').hidden = true;

        await updateUser();
        await load();

        msg('Você saiu da sua conta.');

    } catch (erro) {
        msg(erro.message);
    }
};

$('#search').onkeydown = async evento => {
    if (evento.key !== 'Enter') return;

    const termo = evento.target.value.trim();

    if (!termo) {
        await load();
        msg('');
        return;
    }

    try {
        const usuarios = await api(
            '/busca/' + encodeURIComponent(termo)
        );

        if (!usuarios.length) {
            render([]);
            msg('Nenhum fotógrafo encontrado.');
            return;
        }

        const fotografias = await api(
            '/fotografos/' +
            encodeURIComponent(usuarios[0].nome_usuario) +
            '/publicacoes'
        );

        render(fotografias);

        msg('Publicações de ' + usuarios[0].nome + '.');

    } catch (erro) {
        msg(erro.message);
    }
};

$('#photoForm').onsubmit = async evento => {
    evento.preventDefault();

    if (!me || me.tipo !== 'fotografo') {
        openLogin();
        return;
    }

    try {
        const resposta = await fetch('/api/publicacoes', {
            method: 'POST',
            body: new FormData(evento.target),
            credentials: 'same-origin'
        });

        const dados = await resposta.json();

        if (!resposta.ok) {
            throw new Error(dados.erro || 'Erro ao publicar.');
        }

        evento.target.reset();

        await load();

        msg('Fotografia publicada com sucesso!');

    } catch (erro) {
        msg(erro.message);
    }
};

async function start() {
    try {
        const dados = await api('/me');

        me = dados.usuario;

        await updateUser();
        await load();

    } catch (erro) {
        console.error('Erro ao iniciar o site:', erro);
        msg('Não foi possível carregar as fotografias. Confira o servidor e o MySQL.');
    }
}

start();
